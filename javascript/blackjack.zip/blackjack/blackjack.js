function getCardImageUrl(card) {
    var cardValue = "";
    var suit = "";
    switch (card.point) {
        case 1:
            cardValue = "ace";
            break;
        case 11:
            cardValue = "jack";
            break;
        case 12:
            cardValue = "queen";
            break;
        case 13:
            cardValue = "king";
            break;
        default:
            cardValue = card.point;
    }
    switch (card.suit) {
        case "diamonds":
            suit = "diamonds";
            break;
        case "clubs":
            suit = "clubs";
            break;
        case "spades":
            suit = "spades";
            break;
        case "hearts":
            suit = "hearts"
            break;
    }
    return "images/" + cardValue + "_of_" + suit + ".png";
}

function calculatePoints(cards) {
  var ret = 0;
  var addedAce=false;
  var aces=0;
  for(i=0;i<cards.length;i++){
    var point = 0;
    var card = cards[i];
    switch (card.point) {
        case 1:
            point = 11;
            aces++;
            break;
        case 11:
            point = 10;
            break;
        case 12:
            point = 10;
            break;
        case 13:
            point = 10;
            break;
        default:
            point = card.point;
    }

    ret = ret+point;
  }

  aceIndex=1;
  while(aceIndex<=aces){
    if(ret>21){
      ret = ret-10;
    }
    aceIndex++;
  }

  return ret;
}

function newDeck(){
  var cards = [];
  var suits = ["spades","hearts","clubs","diamonds"];
  for(i=1;i<=13;i++){
      for(s=0;s<4;s++){
        cards.push({point:i,suit:suits[s]});
      }
  }
  return cards;
}


$(document).ready(function() {
  var deck = [];
  var dealerHand = [];
  var playerHand = [];
    $("#deal-button").click(function(){
        deck = shuffle(newDeck())
        $("#dealer-hand").empty();
        $("#player-hand").empty();
        $("#messages").empty();

        dealerHand=[deck.pop(),deck.pop()];
        playerHand=[deck.pop(),deck.pop()];

        for(i=0;i<dealerHand.length;i++){
            card=dealerHand[i];
            $("#dealer-hand").append("<img src=\"" + getCardImageUrl(card)+"\"/>");
        }

        for(i=0;i<playerHand.length;i++){
            card=playerHand[i];
            $("#player-hand").append("<img src=\"" + getCardImageUrl(card)+"\"/>");
        }

        showPoints(dealerHand,"dealer");
        showPoints(playerHand,"player");

    });
    $("#hit-button").click(function(){
      var card = deck.pop();
      playerHand.push(card);
      $("#player-hand").append("<img src=\"" + getCardImageUrl(card)+"\"/>");
      showPoints(playerHand,"player");
      if(calculatePoints(playerHand)>21){
          $("#messages").append("<h1>Dealer Wins</h1>");
      }
    });

    $("#stand-button").click(function(){
      var dealerScore = calculatePoints(dealerHand);
      while (dealerScore<=16) {
          var card= deck.pop();
          dealerHand.push(card);
          $("#dealer-hand").append("<img src=\"" + getCardImageUrl(card)+"\"/>");
          showPoints(dealerHand,"dealer");
          dealerScore = calculatePoints(dealerHand);
      }

      playerScore = calculatePoints(playerHand);
      if(playerScore>dealerScore){
        $("#messages").append("<h1>Player Wins</h1>");
      } else if (playerScore==dealerScore) {
        $("#messages").append("<h1>Push</h1>");
      } else if (dealerScore>21) {
        $("#messages").append("<h1>Player Wins</h1>");
      } else {
        $("#messages").append("<h1>Dealer Wins</h1>");
      }
    });
});

function showPoints(cards,target){
    $("#"+target+"-points").text(calculatePoints(cards));
}

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}
